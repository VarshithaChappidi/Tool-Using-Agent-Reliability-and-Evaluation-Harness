# Tool-Using Agent Reliability and Evaluation Harness

A deterministic support-workflow agent and scenario harness for testing tool use, validation, bounded retries, approval gates, and failure recovery.

> **Scope:** This is a local evaluation project using mock service APIs. It does not connect to real customer systems and does not execute external state-changing operations.

## Problem
Tool-using assistants can fail when APIs time out, return malformed data, or receive ambiguous instructions. A successful response is not enough: the workflow must validate inputs, handle failures predictably, and require human approval before consequential actions.

## What is included
- Pydantic schemas for requests, tool results, and structured outcomes.
- LangGraph workflow: retrieve context -> validate intent -> call a mock read-only service -> draft an action -> approval gate.
- Mock tools with configurable timeout and malformed-response scenarios.
- Bounded retry policy and explicit error categories.
- Evaluation suite measuring task success, recovery rate, tool errors, and latency.
- Pytest coverage for normal, timeout, malformed response, ambiguous request, prompt-injection-like input, and approval-required behavior.
- Optional MLflow logging for experiment metrics.

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m app.cli --scenario normal
python scripts/evaluate.py
pytest -q
```

## Safety model
- The included mock service only reads synthetic ticket records.
- The agent drafts a proposed update but never applies it.
- The `approval_required` field is always true for state-changing suggestions.
- Untrusted user text is treated as data, not as instructions to bypass workflow policy.
- Retries are bounded and only used for transient tool failures.

## Evaluation
Run `python scripts/evaluate.py --output reports/evaluation.json`. The report includes:
- `task_success_rate`: proportion of scenarios that reach a valid, useful result.
- `recovery_rate`: proportion of injected transient failures that recover within the retry budget.
- `tool_error_rate`: proportion of tool invocations ending in errors.
- `mean_latency_ms`: mean end-to-end wall-clock latency.

The included scenarios are synthetic. Report actual results from your own run; do not present the sample metrics as production performance.

## MLflow
Set `MLFLOW_TRACKING_URI` if you want to log the aggregate metrics to an MLflow server. If no tracking server is configured, the evaluator still writes local JSON output.

## Limitations and next steps
- The mock tools are deterministic and do not represent real API reliability distributions.
- Add a persistent trace store, per-tool timeout budgets, idempotency keys, and redacted structured logs for a real integration.
- Expand evaluation with adversarial paraphrases and human-reviewed task-quality labels.
- Pin and review dependency versions before production use.
